package com.nurseitov.currencyconverterapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyConverterApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
